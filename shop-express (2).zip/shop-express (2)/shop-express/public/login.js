// Form validation and navigation
const loginForm = document.getElementById('loginForm');
const loginBtn = document.getElementById('loginBtn');
const loginEmail = document.getElementById('loginEmail');
const loginPassword = document.getElementById('loginPassword');
const errors = {
  loginEmail: document.getElementById('loginEmailError'),
  loginPassword: document.getElementById('loginPasswordError')
};

function validateLogin() {
  let valid = true;
  errors.loginEmail.style.display = loginEmail.value ? 'none' : 'block';
  if(!loginEmail.value) valid = false;

  errors.loginPassword.style.display = loginPassword.value ? 'none' : 'block';
  if(!loginPassword.value) valid = false;

  loginBtn.classList.toggle('active', valid);
  return valid;
}

loginForm.addEventListener('input', validateLogin);

loginForm.addEventListener('submit', function(e){
  e.preventDefault();
  if(validateLogin()){
    // Redirect to dashboard after successful login
    window.location.href = 'dashboard.html'; 
    // Optionally, add authentication logic here before redirecting
  }
});

validateLogin();