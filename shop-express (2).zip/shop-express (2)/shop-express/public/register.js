// Avatar upload logic (optional)
const avatarUpload = document.getElementById('avatarUpload');
const avatarInput = document.getElementById('avatarInput');
const avatarPreview = document.getElementById('avatarPreview');
const avatarPlaceholder = document.getElementById('avatarPlaceholder');

avatarUpload.onclick = () => avatarInput.click();
avatarInput.onchange = () => {
  const file = avatarInput.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = e => {
      avatarPreview.src = e.target.result;
      avatarPreview.style.display = 'block';
      avatarPlaceholder.style.display = 'none';
    };
    reader.readAsDataURL(file);
  }
};

// Form validation and navigation
const signupForm = document.getElementById('signupForm');
const signupBtn = document.getElementById('signupBtn');
const displayName = document.getElementById('displayName');
const email = document.getElementById('email');
const password = document.getElementById('password');
const confirmPassword = document.getElementById('confirmPassword');
const errors = {
  displayName: document.getElementById('displayNameError'),
  email: document.getElementById('emailError'),
  password: document.getElementById('passwordError'),
  confirmPassword: document.getElementById('confirmPasswordError')
};

function validateForm() {
  let valid = true;
  errors.displayName.style.display = displayName.value ? 'none' : 'block';
  if(!displayName.value) valid = false;

  const emailPattern = /^[^@]+@[^@]+\.[^@]+$/;
  errors.email.style.display = emailPattern.test(email.value) ? 'none' : 'block';
  if(!emailPattern.test(email.value)) valid = false;

  errors.password.style.display = password.value.length >= 6 ? 'none' : 'block';
  if(password.value.length < 6) valid = false;

  errors.confirmPassword.style.display = (password.value === confirmPassword.value && password.value.length >= 6) ? 'none' : 'block';
  if(password.value !== confirmPassword.value || password.value.length < 6) valid = false;

  signupBtn.classList.toggle('active', valid);
  return valid;
}

signupForm.addEventListener('input', validateForm);

signupForm.addEventListener('submit', async function(e){
  e.preventDefault();
  // Hide all errors
  ['displayNameError','emailError','passwordError','confirmPasswordError','signupError'].forEach(id => {
    document.getElementById(id).style.display = 'none';
  });

  const name = document.getElementById('displayName').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const confirm = document.getElementById('confirmPassword').value;

  let valid = true;
  if (!name) {
    document.getElementById('displayNameError').style.display = 'block';
    valid = false;
  }
  if (!email.match(/^[^@]+@[^@]+\.[^@]+$/)) {
    document.getElementById('emailError').style.display = 'block';
    valid = false;
  }
  if (password.length < 6) {
    document.getElementById('passwordError').style.display = 'block';
    valid = false;
  }
  if (password !== confirm) {
    document.getElementById('confirmPasswordError').style.display = 'block';
    valid = false;
  }
  if (!valid) return;

  // Prepare form data
  const formData = {
    name,
    email,
    password
    // You can add avatar upload logic here if backend supports it
  };

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(formData)
    });
    if (res.ok) {
      alert('Registered — please login');
      window.location.href = '/login.html';
    } else {
      const data = await res.json().catch(() => ({}));
      document.getElementById('signupError').innerText = data.error || "Register failed. Try a different email.";
      document.getElementById('signupError').style.display = 'block';
    }
  } catch {
    document.getElementById('signupError').innerText = "Network error. Please try again.";
    document.getElementById('signupError').style.display = 'block';
  }
});

validateForm();