// Utility function
function fmt(n) {
  return '₹' + Number(n).toFixed(2);
}

// Index page logic
const productsRoot = document.getElementById('products-list');
if (productsRoot) {
  const searchInput = document.getElementById('search');
  const sortSelect = document.getElementById('sort');
  const filterSelect = document.getElementById('filter');
  const groupbySelect = document.getElementById('groupby');
  let allProducts = [];

  async function loadProducts() {
    productsRoot.innerHTML = '<div style="color:var(--muted);padding:24px;">Loading products...</div>';
    try {
      const res = await fetch('/api/products');
      if (!res.ok) throw new Error('Failed to fetch products');
      allProducts = await res.json();
      renderProducts();
    } catch (err) {
      productsRoot.innerHTML = '<div style="color:red;padding:24px;">Error loading products.</div>';
    }
  }

  function renderProducts() {
    let products = [...allProducts];

    // Search
    const searchVal = searchInput.value.trim().toLowerCase();
    if (searchVal) {
      products = products.filter(p =>
        p.title.toLowerCase().includes(searchVal) ||
        (p.description && p.description.toLowerCase().includes(searchVal))
      );
    }

    // Filter
    const filterVal = filterSelect.value;
    if (filterVal) {
      products = products.filter(p => p.category === filterVal);
    }

    // Sort
    const sortVal = sortSelect.value;
    if (sortVal === 'price-asc') {
      products.sort((a, b) => a.price - b.price);
    } else if (sortVal === 'price-desc') {
      products.sort((a, b) => b.price - a.price);
    } else if (sortVal === 'title') {
      products.sort((a, b) => a.title.localeCompare(b.title));
    }

    // GroupBy
    const groupVal = groupbySelect.value;
    if (groupVal === 'category') {
      const grouped = {};
      products.forEach(p => {
        const cat = p.category ? p.category : "Other";
        grouped[cat] = grouped[cat] || [];
        grouped[cat].push(p);
      });
      productsRoot.innerHTML = Object.entries(grouped).map(([cat, items]) => `
        <div class="card-grid">
          ${items.map(renderProductCard).join('')}
        </div>
      `).join('');
      return;
    }

    // Render products
    productsRoot.innerHTML = products.length
      ? `<div class="grid">${products.map(renderProductCard).join('')}</div>`
      : '<div style="color:var(--muted);padding:24px;">No products found.</div>';
  }

  function renderProductCard(p) {
    return `
      <div class="card">
        <img src="${p.image_url || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'}" alt="${p.title || 'Product image'}">
        <div class="title">${p.title}</div>
        <div class="price">${fmt(p.price)}</div>
        <div class="description">${p.description ? p.description.slice(0,80) : ''}</div>
        <div class="card-actions">
          <a class="btn small" href="/product.html?id=${p._id}">View</a>
          <button class="btn small" onclick="addToCart('${p._id}')">Add to cart</button>
        </div>
      </div>
    `;
  }

  // Event listeners
  if (searchInput && sortSelect && filterSelect && groupbySelect) {
    searchInput.addEventListener('input', renderProducts);
    sortSelect.addEventListener('change', renderProducts);
    filterSelect.addEventListener('change', renderProducts);
    groupbySelect.addEventListener('change', renderProducts);
  }

  const clearBtn = document.getElementById('clear-filters');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      searchInput.value = '';
      sortSelect.value = 'title';
      filterSelect.value = '';
      groupbySelect.value = '';
      renderProducts();
    });
  }

  async function addToCart(id) {
    const res = await fetch('/api/cart/add/' + id, { method: 'POST' });
    if (res.ok) {
      alert('Added to cart ✅');
    } else {
      alert('Failed to add to cart');
    }
  }

  loadProducts();
}

// Product page logic
const productRoot = document.getElementById('product');
if (productRoot) {
  const id = new URLSearchParams(location.search).get('id');
  async function loadProduct() {
    const r = await fetch('/api/products/' + id);
    if (!r.ok) {
      productRoot.innerText = 'Product not found';
      return;
    }
    const p = await r.json();
    productRoot.innerHTML = `
      <div class="card" style="display:flex;gap:12px;align-items:flex-start">
        <img src="${p.image_url || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'}" style="width:320px;height:220px;flex-shrink:0" />
        <div>
          <h2 style="margin-top:0">${p.title}</h2>
          <div class="price">${fmt(p.price)}</div>
          <p style="color:var(--muted)">${p.description || ''}</p>
          <div style="display:flex;gap:8px;margin-top:12px">
            <button class="btn" onclick="add('${p._id}')">Add to cart</button>
            <a class="btn" href="/">Back</a>
          </div>
        </div>
      </div>
    `;
  }

  async function add(id) {
    await fetch('/api/cart/add/' + id, { method: 'POST' });
    alert('Added to cart');
  }

  loadProduct();
}


document.getElementById('f').onsubmit = async e => {
  e.preventDefault();
  const form = Object.fromEntries(new FormData(e.target));
  const res = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
  if (res.ok) {
    const { token } = await res.json();
    localStorage.setItem('token', token);
    alert('Logged in');
    location.href = '/';
  } else {
    alert('Login failed');
  }
}
