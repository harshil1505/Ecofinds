document.getElementById('user-name').innerText = "Jane Doe";
document.getElementById('user-email').innerText = "jane.doe@email.com";
document.getElementById('user-other').innerText = "Member since 2024";
document.getElementById('cart-count').innerText = "2";

function editProfile() {
  alert('Edit profile functionality coming soon!');
}
