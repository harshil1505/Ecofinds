const router = require('express').Router();
const { products } = require('../data/store');

router.get('/', (req, res) => {
  res.json(req.session.cart || {});
});

router.post('/add/:id', (req, res) => {
  const p = products.find(x => x._id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  const cart = req.session.cart || {};
  cart[p._id] = (cart[p._id] || 0) + 1;
  req.session.cart = cart;
  res.json(cart);
});

router.post('/remove/:id', (req, res) => {
  const cart = req.session.cart || {};
  delete cart[req.params.id];
  req.session.cart = cart;
  res.json(cart);
});

module.exports = router;
