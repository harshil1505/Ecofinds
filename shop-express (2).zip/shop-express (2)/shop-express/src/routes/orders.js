const router = require('express').Router();
const { products, orders } = require('../data/store');
const { requireAuth } = require('../utils/authMiddleware');
const { randomUUID } = require('crypto');

router.post('/checkout', requireAuth, (req, res) => {
  const cart = req.session.cart || {};
  const ids = Object.keys(cart);
  if (!ids.length) return res.status(400).json({ error: 'Cart is empty' });

  let total = 0;
  const items = ids.map(id => {
    const p = products.find(x => x._id === id);
    const qty = cart[id];
    const price_each = p.price;
    total += price_each * qty;
    return { product: id, title: p.title, quantity: qty, price_each };
  });

  const order = { _id: randomUUID(), user: req.user._id, items, total, status: 'NEW', createdAt: new Date() };
  orders.push(order);
  req.session.cart = {}; // clear
  res.json(order);
});

router.get('/my', requireAuth, (req, res) => {
  const my = orders.filter(o => o.user === req.user._id);
  res.json(my);
});

module.exports = router;
