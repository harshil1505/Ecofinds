const router = require('express').Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { users } = require('../data/store');
const { randomUUID } = require('crypto');

const SECRET = process.env.JWT_SECRET || 'dev_jwt_secret';

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  if (users.find(u => u.email === email)) return res.status(400).json({ error: 'Email already in use' });
  const password_hash = await bcrypt.hash(password, 10);
  const user = { _id: randomUUID(), email, password_hash, name: name || '', is_admin: false, createdAt: new Date() };
  users.push(user);
  res.json({ id: user._id, email: user.email });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ sub: user._id }, SECRET, { expiresIn: '7d' });
  res.json({ token });
});

module.exports = router;
