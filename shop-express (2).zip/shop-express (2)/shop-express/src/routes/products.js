const router = require('express').Router();
const { products } = require('../data/store');

router.get('/', (req, res) => res.json(products));
router.get('/:id', (req, res) => {
  const p = products.find(x => x._id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

module.exports = router;
