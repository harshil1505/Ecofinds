const products = require('./products.json');
const users = [];   // persisted only in memory (will migrate later)
const orders = [];
module.exports = { products, users, orders };
